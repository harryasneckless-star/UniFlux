# UniFlux — starter technique

Prototype initial d'une application Android de circulation des demandes de matières universitaires.

## Stack
- Kotlin, Jetpack Compose, Gradle
- Firebase Authentication
- Cloud Firestore

## Important
Ce dépôt est un **squelette de démarrage**, pas une application de production complète.
Les écrans de création de demande, le moteur de circulation, les notifications, les fonctions backend sécurisées et les tests restent à implémenter.

Le formulaire de connexion mappe le matricule vers un alias Firebase réservé (`<matricule>@login.uniflux.example`). Les comptes doivent être provisionnés par l'administration dans Firebase Authentication, avec un mot de passe temporaire sûr et une procédure de changement. Ce mécanisme est un choix de prototype et doit être validé avant tout déploiement réel. Ne jamais considérer le matricule comme un secret.

## Configuration
1. Installer Android Studio et un JDK compatible avec Android Gradle Plugin 8.7.
2. Créer un projet Firebase.
3. Activer Firebase Authentication avec Email/Password et créer la base Firestore.
4. Ajouter l'application Android avec l'identifiant `mg.uniflux.app`.
5. Télécharger `google-services.json` et le placer dans `app/`.
6. Déployer `firestore.rules` dans Firebase.
7. Ouvrir le projet dans Android Studio, synchroniser Gradle, puis compiler.

## Modèle de données Firestore proposé

### `users/{uid}`
- `matricule`: string (unique, vérifié par l'administration)
- `displayName`: string
- `role`: `ETUDIANT`, `AGENT`, `RESPONSABLE` ou `ADMIN`
- `active`: boolean
- `filiereId`: string (étudiants)
- `level`: string (étudiants)
- `serviceIds`: array<string> (personnel)
- `createdAt`: timestamp

### `subjects/{subjectId}`
- `code`: string
- `name`: string
- `filiereIds`: array<string>
- `level`: string
- `academicYear`: string
- `active`: boolean

### `services/{serviceId}`
- `name`: string
- `active`: boolean
- `sequence`: number (ordre indicatif, si le circuit est linéaire)

### `requests/{requestId}`
- `reference`: string
- `studentUid`: string
- `studentMatricule`: string
- `filiereId`: string
- `level`: string
- `academicYear`: string
- `subjectIds`: array<string>
- `reason`: string
- `status`: string
- `currentServiceId`: string
- `currentStep`: number
- `createdAt`: timestamp
- `updatedAt`: timestamp
- `decisionReason`: string nullable

### `requests/{requestId}/history/{eventId}`
- `actorUid`: string
- `actorRole`: string
- `serviceId`: string nullable
- `action`: string
- `fromStatus`: string nullable
- `toStatus`: string
- `comment`: string nullable
- `createdAt`: timestamp

## Modèle de sécurité
Les clients ne peuvent pas créer ou modifier directement les demandes et l'historique. Il faut ajouter des fonctions backend fiables (par exemple Firebase Cloud Functions) pour :
- créer une demande après validation des matières et du profil ;
- attribuer une référence unique ;
- faire avancer le circuit ;
- valider les permissions de l'agent ;
- écrire l'historique dans une transaction ;
- effectuer les décisions finales.

Tester les règles avec Firebase Emulator Suite avant toute utilisation réelle.

## Compiler un APK
Dans Android Studio : `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
Pour une distribution réelle, configurer une signature de release et garder la clé de signature hors du dépôt.
