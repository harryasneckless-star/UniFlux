package mg.uniflux.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    UniFluxApp()
                }
            }
        }
    }
}

@Composable
private fun UniFluxApp() {
    var matricule by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Connectez-vous avec les identifiants fournis par l'administration.") }
    var loading by remember { mutableStateOf(false) }
    var signedInUid by remember { mutableStateOf<String?>(FirebaseAuth.getInstance().currentUser?.uid) }

    if (signedInUid != null) {
        StudentHome(
            uid = signedInUid!!,
            onLogout = {
                FirebaseAuth.getInstance().signOut()
                signedInUid = null
                message = "Vous êtes déconnecté."
            }
        )
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start
    ) {
        Text("UniFlux", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Suivi des demandes de matières universitaires")
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(
            value = matricule, onValueChange = { matricule = it.trim() },
            label = { Text("Numéro matricule") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password, onValueChange = { password = it },
            label = { Text("Mot de passe") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Button(
            enabled = !loading && matricule.isNotBlank() && password.isNotBlank(),
            onClick = {
                loading = true
                message = "Connexion en cours…"
                // Prototype: matricule is mapped to a reserved alias.
                // Provision matching Firebase Auth accounts administratively.
                val alias = "${matricule.lowercase()}@login.uniflux.example"
                FirebaseAuth.getInstance().signInWithEmailAndPassword(alias, password)
                    .addOnCompleteListener { task ->
                        loading = false
                        if (task.isSuccessful) {
                            signedInUid = FirebaseAuth.getInstance().currentUser?.uid
                            message = "Connexion réussie."
                        } else {
                            message = "Connexion impossible. Vérifiez vos identifiants ou contactez l'administration."
                        }
                    }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (loading) "Connexion…" else "Se connecter") }
        Spacer(Modifier.height(12.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(20.dp))
        Text(
            "Accès étudiant : le compte doit être créé et activé par l'administration. " +
                "Le matricule seul ne suffit jamais pour se connecter.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun StudentHome(uid: String, onLogout: () -> Unit) {
    var name by remember { mutableStateOf("Étudiant") }
    var status by remember { mutableStateOf("Chargement du profil…") }

    LaunchedEffect(uid) {
        FirebaseFirestore.getInstance().collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                name = doc.getString("displayName") ?: "Étudiant"
                status = if (doc.getBoolean("active") == true) {
                    "Compte actif. Le formulaire de demande sera ajouté dans la prochaine étape."
                } else {
                    "Compte en attente d'activation par l'administration."
                }
            }
            .addOnFailureListener { status = "Profil indisponible. Vérifiez la connexion." }
    }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("UniFlux", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("Bonjour, $name", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(status)
        Spacer(Modifier.height(24.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Mes demandes", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text("La création et le suivi des demandes seront implémentés dans la prochaine étape.")
            }
        }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) {
            Text("Se déconnecter")
        }
    }
}
