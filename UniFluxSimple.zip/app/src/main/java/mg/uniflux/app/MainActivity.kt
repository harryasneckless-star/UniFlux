package mg.uniflux.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class DemoRequest(
    val subject: String,
    val reason: String,
    val reference: String,
    val status: String = "En attente"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { UniFluxScreen() } }
    }
}

@Composable
private fun UniFluxScreen() {
    var matricule by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("Version de démonstration : les demandes restent sur cet écran.") }
    val requests = remember { mutableStateListOf<DemoRequest>() }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("UniFlux", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Demandes de matières universitaires", style = MaterialTheme.typography.titleMedium)
        Text("DÉMONSTRATION", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        OutlinedTextField(
            value = matricule, onValueChange = { matricule = it },
            label = { Text("Matricule étudiant") }, modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = subject, onValueChange = { subject = it },
            label = { Text("Matière demandée") }, modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = reason, onValueChange = { reason = it },
            label = { Text("Motif de la demande") }, modifier = Modifier.fillMaxWidth(),
            minLines = 2
        )
        Button(
            onClick = {
                if (matricule.isBlank() || subject.isBlank() || reason.isBlank()) {
                    notice = "Remplis le matricule, la matière et le motif."
                } else {
                    val ref = "UF-${(1000..9999).random()}"
                    requests.add(0, DemoRequest(subject.trim(), reason.trim(), ref))
                    notice = "Demande $ref créée pour le matricule $matricule."
                    subject = ""
                    reason = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Envoyer une demande (démo)") }
        Text(notice, style = MaterialTheme.typography.bodySmall)
        HorizontalDivider()
        Text("Mes demandes", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        if (requests.isEmpty()) {
            Text("Aucune demande pour le moment.", style = MaterialTheme.typography.bodyMedium)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(requests) { req ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(req.subject, fontWeight = FontWeight.Bold)
                            Text("Référence : ${req.reference}")
                            Text("Motif : ${req.reason}")
                            AssistChip(onClick = {}, label = { Text(req.status) })
                        }
                    }
                }
            }
        }
        Text(
            "Cette version ne se connecte pas à Internet et ne sauvegarde pas les données après fermeture.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
