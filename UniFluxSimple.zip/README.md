# UniFlux — version simple de démonstration

Cette version Android permet de saisir un matricule, une matière et un motif, puis d'afficher la demande sur l'écran. Elle est destinée aux essais uniquement.

- Pas de compte réel
- Pas de base de données / synchronisation
- Les demandes disparaissent quand l'application est fermée
- Ne pas utiliser pour des données réelles d'étudiants

## Compilation sur GitHub Actions

Le dépôt doit contenir les fichiers Android décompressés à sa racine (dossiers `app`, fichiers Gradle, etc.). Le fichier ZIP seul ne suffit pas pour lancer une compilation Android standard.

Le workflow `android-build.yml` fourni séparément doit être placé dans `.github/workflows/android-build.yml`.
